package com.mealkit.contextmenu;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
Button contextButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        contextButton = findViewById(R.id.context_btn);
        registerForContextMenu(contextButton);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getMenuInflater().inflate(R.menu.my_menu,menu);
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.red:
                contextButton.setBackgroundColor(Color.RED);
            break;
            case R.id.green:
                contextButton.setBackgroundColor(Color.GREEN);
                break;
            case R.id.blue:
                contextButton.setBackgroundColor(Color.BLUE);
                break;
            case R.id.yellow:
                contextButton.setBackgroundColor(Color.YELLOW);
                break;
        }

        return super.onContextItemSelected(item);
    }
}

package in.visiontek.jsonparsingapi;

public class Kitten {
    String creatorName,imageUrl;
    int numLikes;

    public Kitten(String creatorName, String imageUrl, int numLikes) {
        this.creatorName = creatorName;
        this.imageUrl = imageUrl;
        this.numLikes = numLikes;
    }

    public String getCreatorName() {
        return creatorName;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public int getNumLikes() {
        return numLikes;
    }
}

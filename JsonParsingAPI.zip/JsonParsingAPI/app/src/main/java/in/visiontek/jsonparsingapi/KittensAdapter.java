package in.visiontek.jsonparsingapi;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class KittensAdapter extends RecyclerView.Adapter<KittensAdapter.MyViewHolder> {
    Context context;
    ArrayList<Kitten> kittenArrayList;

    public KittensAdapter(Context applicationContext, ArrayList<Kitten> kittenArrayList) {
        this.context = applicationContext;
        this.kittenArrayList = kittenArrayList;
    }

    @NonNull
    @Override
    public KittensAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.card_item,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull KittensAdapter.MyViewHolder holder, int position) {
        Kitten kitten = kittenArrayList.get(position);
        String creatorName = kitten.getCreatorName();
        String numLikes = String.valueOf(kitten.getNumLikes());
        String imageUrl = kitten.getImageUrl();

        holder.creatorName.setText(creatorName);
        holder.numLikes.setText(numLikes);
        Glide.with(context).load(imageUrl).into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return kittenArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView imageView;
        TextView creatorName, numLikes;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.kitten_image);
            creatorName = itemView.findViewById(R.id.creator_name);
            numLikes = itemView.findViewById(R.id.num_likes);
        }
    }
}

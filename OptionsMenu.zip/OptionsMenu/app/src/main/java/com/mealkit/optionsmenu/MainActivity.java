package com.mealkit.optionsmenu;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
TextView myTitle;
RelativeLayout parent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myTitle = findViewById(R.id.my_text);
        parent = findViewById(R.id.my_parent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.my_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.red:
                myTitle.setTextColor(Color.RED);
                break;
            case R.id.green:
                //myTitle.setTextColor(Color.GREEN);
                parent.setBackgroundColor(Color.LTGRAY);
                break;
            case R.id.blue:
                //myTitle.setTextColor(Color.BLUE);
                parent.setBackgroundResource(R.drawable.ic_launcher_background);
                break;
            case R.id.yellow:
                myTitle.setTextColor(Color.YELLOW);
                break;
        }

        return super.onOptionsItemSelected(item);
    }
}

package com.mealkit.sharedprefs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
EditText name, email;
SharedPreferences sharedPreferences;
final String FILE_NAME = "my_prefs";
    SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name = findViewById(R.id.name_et);
        email = findViewById(R.id.email_et);
        sharedPreferences = getSharedPreferences(FILE_NAME,MODE_PRIVATE);

    }

    public void savePrefs(View view) {
         editor = sharedPreferences.edit();
        editor.putString("Name",name.getText().toString());
        editor.putString("Email",email.getText().toString());
        editor.commit();
    }

    public void loadPrefs(View view) {
        if (sharedPreferences.contains("Name"))
        {
            name.setText(sharedPreferences.getString("Name",null));
        }
        if (sharedPreferences.contains("Email"))
        {
            email.setText(sharedPreferences.getString("Email",null));
        }

    }

    public void clearValues(View view) {
        name.setText("");
        email.setText("");
    }
}

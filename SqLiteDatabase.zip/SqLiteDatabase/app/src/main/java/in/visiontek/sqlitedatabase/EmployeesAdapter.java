package in.visiontek.sqlitedatabase;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class EmployeesAdapter extends RecyclerView.Adapter<EmployeesAdapter.MyViewHolder>{
    ArrayList<Employee> employeeArrayList;
    DBHelper dbHelper;
    int currentPosition;
    Context context;
    public EmployeesAdapter(Context context, ArrayList<Employee> employeeArrayList) {
        this.context = context;
        this.employeeArrayList =employeeArrayList;
    }

    @NonNull
    @Override
    public EmployeesAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_item,null);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EmployeesAdapter.MyViewHolder holder, int position) {

        dbHelper = new DBHelper(context);
        Employee employee = employeeArrayList.get(position);

       holder.name.setText(employee.getEmpName());
       holder.email.setText(employee.getEmpEmail());

       holder.itemView.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

               PopupMenu popupMenu = new PopupMenu(context,v);
               currentPosition = holder.getAdapterPosition();
               popupMenu.getMenuInflater().inflate(R.menu.popup_menu,popupMenu.getMenu());

               popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                   @Override
                   public boolean onMenuItemClick(MenuItem item) {
                       if (item.getItemId() == R.id.edit){
                            editEmployee();
                       }
                       else if (item.getItemId() == R.id.delete){
                            deleteEmployee();
                       }

                       return true;
                   }
               });
               popupMenu.show();
           }
       });

    }

    private void deleteEmployee() {
        dbHelper.deleteEmp(employeeArrayList.get(currentPosition).toString());
        employeeArrayList.remove(currentPosition);
        notifyItemRemoved(currentPosition);

    }

    private void editEmployee() {
        Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.add_emp_alert);
        dialog.show();
        EditText name = dialog.findViewById(R.id.emp_name);
        EditText email = dialog.findViewById(R.id.emp_email);
        Button updateBtn = dialog.findViewById(R.id.add_button);
        updateBtn.setText(R.string.update);

        Employee employee = employeeArrayList.get(currentPosition);
        name.setText(employee.getEmpName());
        email.setText(employee.getEmpEmail());
        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String updatedName = name.getText().toString();
                String updatedEmail = email.getText().toString();
                dbHelper.updateEmp(updatedName,updatedEmail);
                employeeArrayList = dbHelper.getEmployees();
                notifyItemChanged(currentPosition);
                dialog.dismiss();
            }
        });

    }

    @Override
    public int getItemCount() {
        return employeeArrayList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        TextView name,email;
        public MyViewHolder(View view) {
            super(view);

            name = view.findViewById(R.id.emp_name);
            email = view.findViewById(R.id.emp_email);

        }
    }
}

package in.visiontek.sqlitedatabase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
DBHelper dbHelper;
RecyclerView recyclerView;
EmployeesAdapter employeesAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DBHelper(this);
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        ArrayList<Employee> employeeArrayList = dbHelper.getEmployees();
        employeesAdapter = new EmployeesAdapter(this,employeeArrayList);
        recyclerView.setAdapter(employeesAdapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        EditText nameEdit, emailEdit;
        Button addButton;
        switch (item.getItemId()){
            case R.id.option_add_emp:
                Dialog dialog = new Dialog(this);
                dialog.setContentView(R.layout.add_emp_alert);
                 nameEdit = dialog.findViewById(R.id.emp_name);
                 emailEdit = dialog.findViewById(R.id.emp_email);
                 addButton = dialog.findViewById(R.id.add_button);
                 addButton.setText(R.string.add);
                 addButton.setOnClickListener(new View.OnClickListener() {
                     @Override
                     public void onClick(View v) {
                         boolean result = dbHelper.insertEmployee(nameEdit.getText().toString(),emailEdit.getText().toString());
                         if (result){
                             Toast.makeText(MainActivity.this, "Inserted", Toast.LENGTH_SHORT).show();

                         }
                         else{
                             Toast.makeText(MainActivity.this, "Not Inserted", Toast.LENGTH_SHORT).show();
                         }
                         Intent in = new Intent(getApplicationContext(),MainActivity.class);
                         startActivity(in);
                     }
                 });
                dialog.show();

                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
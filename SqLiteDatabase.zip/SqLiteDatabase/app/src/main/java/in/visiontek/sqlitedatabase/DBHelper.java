package in.visiontek.sqlitedatabase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    SQLiteDatabase sqLiteDatabase;
    private static final String DATABASE_NAME = "employees.db";
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_TABLE = "emp_data";
    private static final String KEY_ID = "Id";
    private static final String KEY_NAME = "Name";
    private static final String KEY_EMAIL = "Email";

    private static final String CREATE_TABLE = "create table "+ DATABASE_TABLE +
            "( " + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + KEY_NAME + " TEXT, " + KEY_EMAIL + " TEXT);";
    public DBHelper( Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + DATABASE_TABLE);
        onCreate(db);
    }
    public boolean insertEmployee(String name, String email){
        sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(KEY_NAME,name);
        contentValues.put(KEY_EMAIL,email);
        long result = sqLiteDatabase.insert(DATABASE_TABLE,null,contentValues);
        Log.e("sqlite", String.valueOf(result));
        return result != -1;
    }
    public ArrayList<Employee> getEmployees(){
        ArrayList<Employee> employeeArrayList = new ArrayList<>();
        sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from "+ DATABASE_TABLE,null);
        while (cursor.moveToNext()){
            String name = cursor.getString(1);
            String email = cursor.getString(2);
            Employee employee = new Employee(name,email);
            employeeArrayList.add(employee);
        }
        cursor.close();
        return employeeArrayList;
    }
    public void updateEmp(String name, String email)
    {
        sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(KEY_NAME,name);
        contentValues.put(KEY_EMAIL,email);

        sqLiteDatabase.update(DATABASE_TABLE,contentValues,"name=?", new String[]{name});

    }
    public boolean deleteEmp(String name){
        sqLiteDatabase = this.getWritableDatabase();
        int rows = sqLiteDatabase.delete(DATABASE_TABLE,"name=?",new String[]{name});
        return rows !=0;
    }
}

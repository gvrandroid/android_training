package com.mealkit.customlistarray;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class VersionDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_version_details);
        ImageView vImage = findViewById(R.id.version_imag);
        TextView vName = findViewById(R.id.v_name);


        Intent in = getIntent();
        vImage.setImageResource(in.getIntExtra("myVersion",0));
        vName.setText(in.getStringExtra("myName"));

    }
}

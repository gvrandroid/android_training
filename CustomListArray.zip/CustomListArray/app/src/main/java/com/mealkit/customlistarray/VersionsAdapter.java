package com.mealkit.customlistarray;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class VersionsAdapter extends ArrayAdapter<Version> {

    public VersionsAdapter(@NonNull Context context, ArrayList<Version> versions) {
        super(context, 0,versions);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem = convertView;
        LayoutInflater layoutInflater = LayoutInflater.from(getContext());
        listItem = layoutInflater.inflate(R.layout.list_item_row,null);
        ImageView vImage = listItem.findViewById(R.id.version_image);
        TextView vName = listItem.findViewById(R.id.version_name);

        Version version = getItem(position);
        vImage.setImageResource(version.getVersionImage());
        vName.setText(version.getVersionName());
        return listItem;
    }
}

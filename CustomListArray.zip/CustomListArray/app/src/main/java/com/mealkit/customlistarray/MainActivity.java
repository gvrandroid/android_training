package com.mealkit.customlistarray;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
ListView listView;
ArrayList<Version> versions;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.list_view);
        versions = new ArrayList<>();
        versions.add(new Version("Cupcake", R.drawable.cupcake));
        versions.add(new Version("Donut", R.drawable.donuts));
        versions.add(new Version("Eclair", R.drawable.eclair));
        versions.add(new Version("Froyo", R.drawable.froyo));
        versions.add(new Version("Gingerbread", R.drawable.gingerbread));
        versions.add(new Version("Honeycomb", R.drawable.honeycomb));
        versions.add(new Version("Ice Cream Sandwich", R.drawable.ics));
        versions.add(new Version("Jellybean", R.drawable.jellybean));
        versions.add(new Version("Kitkat", R.drawable.kitkat));
        versions.add(new Version("Lollipop", R.drawable.lollipop));
        versions.add(new Version("Marshmallow", R.drawable.marshmallow));
        versions.add(new Version("Nougat", R.drawable.nougat));

        VersionsAdapter versionsAdapter = new VersionsAdapter(this,versions);
        listView.setAdapter(versionsAdapter);
        listView.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent in = new Intent(this,VersionDetails.class);
        Version version = versions.get(position);
        in.putExtra("myVersion",version.getVersionImage());
        in.putExtra("myName",version.getVersionName());
        startActivity(in);
    }
}

package com.mealkit.customlistarray;

public class Version {
    String versionName;
    int versionImage;

    public Version(String versionName, int versionImage) {
        this.versionName = versionName;
        this.versionImage = versionImage;
    }

    public String getVersionName() {
        return versionName;
    }

    public int getVersionImage() {
        return versionImage;
    }
}

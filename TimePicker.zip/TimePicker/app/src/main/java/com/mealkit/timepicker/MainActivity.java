package com.mealkit.timepicker;

import androidx.appcompat.app.AppCompatActivity;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TimePicker;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements TimePickerDialog.OnTimeSetListener {
EditText time_edit;
int hour, minutes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        time_edit = findViewById(R.id.time_et);
    }

    public void showTimePicker(View view) {
        Calendar c= Calendar.getInstance();
        hour = c.get(Calendar.HOUR);
        minutes = c.get(Calendar.MINUTE);
        TimePickerDialog timePickerDialog = new TimePickerDialog(this,this,hour,minutes,true);
        timePickerDialog.show();

    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        String myTime = hourOfDay +" : "+minute;
        time_edit.setText(myTime);
    }
}

package com.mealkit.spinnerview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
String[] vNames = {"CupCake","Donut","Eclairs","Froyo",
        "GingerBread","HoneyComb","ICS","JellyBeans","KitKat","Lollipop","MarshMallow",
        "Nougat","Oreo","Pie","Q"};
TextView mySelection;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner spinner = findViewById(R.id.spinner);
        mySelection =findViewById(R.id.my_selection);

        ArrayAdapter<String> versionsAdapter = new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,vNames);
        spinner.setAdapter(versionsAdapter);
        spinner.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        mySelection.setText(vNames[position]);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}

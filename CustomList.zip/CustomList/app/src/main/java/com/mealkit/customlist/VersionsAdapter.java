package com.mealkit.customlist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class VersionsAdapter extends ArrayAdapter {
    private String[] versionNames;
    private Integer[] versionImages;
    private Context context;



    public VersionsAdapter(Context context, String[] versionNames, Integer[] versionImages ) {
        super(context,R.layout.list_item_row,versionNames);
        this.versionNames = versionNames;
        this.versionImages = versionImages;
        this.context = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View row = convertView;
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        row = layoutInflater.inflate(R.layout.list_item_row,null);

        ImageView vImage = row.findViewById(R.id.version_image);
        TextView vName = row.findViewById(R.id.version_name);

        vImage.setImageResource(versionImages[position]);
        vName.setText(versionNames[position]);
        return row;
    }
}

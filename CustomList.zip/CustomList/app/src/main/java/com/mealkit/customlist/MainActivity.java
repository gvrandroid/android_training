package com.mealkit.customlist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
ListView listView;
String[] vNames ={"Donut","Eclairs","Froyo","Ginger Bread","Honey Comb","ICS","Jellybean","Kitkat","Lollipop","Marshmallow", "Nougat"};
Integer[] vImages = {R.drawable.donuts,R.drawable.eclair,R.drawable.froyo,
            R.drawable.gingerbread,R.drawable.honeycomb,R.drawable.ics,R.drawable.jellybean,
            R.drawable.kitkat,R.drawable.lollipop,R.drawable.marshmallow,R.drawable.nougat};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.list_view);

        VersionsAdapter versionsAdapter = new VersionsAdapter(this,vNames,vImages);
        listView.setAdapter(versionsAdapter);
        listView.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent in = new Intent(this, SingleVersion.class);
        in.putExtra("myId",position);
        startActivity(in);
    }
}

package com.mealkit.customlist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

public class SingleVersion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_version);
        ImageView vImage = findViewById(R.id.versionLogo);

        Intent in = getIntent();
        int myChoice = in.getExtras().getInt("myId");
        //VersionsAdapter versionsAdapter = new VersionsAdapter(this);
    }
}
